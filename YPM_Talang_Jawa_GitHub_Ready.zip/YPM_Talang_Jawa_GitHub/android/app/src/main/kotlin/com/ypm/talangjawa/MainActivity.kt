package com.ypm.talangjawa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
