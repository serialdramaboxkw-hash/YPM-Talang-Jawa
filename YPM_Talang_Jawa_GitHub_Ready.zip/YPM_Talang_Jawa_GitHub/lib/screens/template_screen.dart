import 'package:flutter/material.dart';
import '../models/template_model.dart';
import '../services/template_service.dart';
import '../utils/constants.dart';
import '../widgets/photo_frame.dart';

class TemplateScreen extends StatefulWidget {
  const TemplateScreen({super.key});
  @override State<TemplateScreen> createState() => _TemplateScreenState();
}

class _TemplateScreenState extends State<TemplateScreen> {
  TemplateModel _m = const TemplateModel();
  @override
  void initState() {
    super.initState();
    TemplateService.load().then((v) { if (mounted) setState(() => _m = v); });
  }

  void _update(TemplateModel Function(TemplateModel) fn) => setState(() => _m = fn(_m));

  Future<void> _save() async {
    await TemplateService.save(_m);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Template disimpan.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Template Utama')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PhotoFrame(
            photo: null,
            template: _m,
            dateText: '20 September 2026 | 13:45 WIB',
            locationText: 'Simpang Kepur, Tanjung Enim',
            showGuides: true,
          ),
          const SizedBox(height: 16),
          _slider('Posisi foto horizontal', _m.photoLeft, 0.02, 0.30,
              (v) => _update((m) => TemplateModel(photoLeft: v, photoTop: m.photoTop, photoWidth: m.photoWidth, photoHeight: m.photoHeight, dateTop: m.dateTop, locationTop: m.locationTop, textScale: m.textScale))),
          _slider('Posisi foto vertikal', _m.photoTop, 0.08, 0.45,
              (v) => _update((m) => TemplateModel(photoLeft: m.photoLeft, photoTop: v, photoWidth: m.photoWidth, photoHeight: m.photoHeight, dateTop: m.dateTop, locationTop: m.locationTop, textScale: m.textScale))),
          _slider('Lebar foto', _m.photoWidth, 0.55, 0.96,
              (v) => _update((m) => TemplateModel(photoLeft: m.photoLeft, photoTop: m.photoTop, photoWidth: v, photoHeight: m.photoHeight, dateTop: m.dateTop, locationTop: m.locationTop, textScale: m.textScale))),
          _slider('Tinggi foto', _m.photoHeight, 0.25, 0.70,
              (v) => _update((m) => TemplateModel(photoLeft: m.photoLeft, photoTop: m.photoTop, photoWidth: m.photoWidth, photoHeight: v, dateTop: m.dateTop, locationTop: m.locationTop, textScale: m.textScale))),
          _slider('Ukuran tulisan', _m.textScale, 0.7, 1.5,
              (v) => _update((m) => TemplateModel(photoLeft: m.photoLeft, photoTop: m.photoTop, photoWidth: m.photoWidth, photoHeight: m.photoHeight, dateTop: m.dateTop, locationTop: m.locationTop, textScale: v))),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan Pengaturan Template')),
          TextButton(onPressed: () => setState(() => _m = const TemplateModel()), child: const Text('Kembalikan ke Pengaturan Awal')),
        ],
      ),
    );
  }

  Widget _slider(String title, double value, double min, double max, ValueChanged<double> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        Slider(value: value.clamp(min, max), min: min, max: max, onChanged: onChanged),
      ],
    );
  }
}
