import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:share_plus/share_plus.dart';

import '../models/template_model.dart';
import '../services/gallery_service.dart';
import '../services/template_service.dart';
import '../widgets/photo_frame.dart';

class PreviewScreen extends StatefulWidget {
  final String imagePath;
  final String dateText;
  final String locationText;

  const PreviewScreen({
    super.key,
    required this.imagePath,
    required this.dateText,
    required this.locationText,
  });

  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  final GlobalKey _exportKey = GlobalKey();
  TemplateModel _template = const TemplateModel();
  bool _saving = false;
  String? _lastExportPath;

  @override
  void initState() {
    super.initState();
    TemplateService.load().then((v) {
      if (mounted) setState(() => _template = v);
    });
  }

  Future<Uint8List> _renderComposite() async {
    // Capture the complete template + photo + date + location as one PNG.
    // The preview stays responsive; the capture scales it to 1024px wide.
    await Future<void>.delayed(const Duration(milliseconds: 80));
    final boundary = _exportKey.currentContext?.findRenderObject()
        as RenderRepaintBoundary?;
    if (boundary == null) {
      throw StateError('Area export belum siap.');
    }

    final logicalWidth = boundary.size.width;
    final pixelRatio = 1024 / logicalWidth;
    final image = await boundary.toImage(pixelRatio: pixelRatio);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    if (data == null) throw StateError('Gagal membuat file PNG.');
    return data.buffer.asUint8List();
  }

  Future<File> _createExportFile() async {
    final bytes = await _renderComposite();
    final dir = await GalleryService.appDirectory();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final file = File('${dir.path}/YPM_Talang_Jawa_$timestamp.png');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  Future<File> _exportAndSave() async {
    final file = await _createExportFile();
    await GalleryService.saveToDeviceGallery(file);
    _lastExportPath = file.path;
    return file;
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await _exportAndSave();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Foto final berhasil disimpan ke Galeri.'),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menyimpan: $e')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _share() async {
    setState(() => _saving = true);
    try {
      final file = _lastExportPath == null
          ? await _createExportFile()
          : File(_lastExportPath!);
      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Serah terima motor - YPM Talang Jawa',
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal membagikan foto: $e')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Preview Serah Terima')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // The visible preview is also the export canvas. The exporter
          // scales this responsive canvas to 1024 x 1536 pixels.
          RepaintBoundary(
            key: _exportKey,
            child: AspectRatio(
              aspectRatio: 1024 / 1536,
              child: PhotoFrame(
                photo: File(widget.imagePath),
                template: _template,
                dateText: widget.dateText,
                locationText: widget.locationText,
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _saving ? null : _save,
            icon: const Icon(Icons.save_alt),
            label: Text(_saving ? 'Memproses...' : 'Simpan ke Galeri'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _saving ? null : _share,
            icon: const Icon(Icons.share),
            label: const Text('Bagikan'),
          ),
          const SizedBox(height: 8),
          const Text(
            'Hasil disimpan sebagai PNG berkualitas tinggi yang sudah menggabungkan template, foto motor, tanggal, dan lokasi.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }
}
