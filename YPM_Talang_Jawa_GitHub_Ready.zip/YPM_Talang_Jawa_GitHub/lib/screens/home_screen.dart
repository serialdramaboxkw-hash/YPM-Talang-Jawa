import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'camera_screen.dart';
import 'gallery_screen.dart';
import 'preview_screen.dart';
import 'template_screen.dart';
import '../services/location_service.dart';
import '../utils/constants.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> _pick(BuildContext context) async {
    final picker = ImagePicker();
    final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 100);
    if (x == null || !context.mounted) return;
    final location = await LocationService.getReadableLocation();
    if (!context.mounted) return;
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => PreviewScreen(
        imagePath: x.path,
        dateText: DateFormat('dd MMMM yyyy | HH:mm', 'id_ID').format(DateTime.now()) + ' WIB',
        locationText: location,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName, style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: AppConstants.yamahaBlue,
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppConstants.yamahaDark, AppConstants.yamahaBlue],
                ),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('YAMAHA', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
                  SizedBox(height: 6),
                  Text('YPM TALANG JAWA', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                  SizedBox(height: 4),
                  Text('Foto Serah Terima Motor', style: TextStyle(color: Colors.white70, fontSize: 15)),
                ],
              ),
            ),
            const SizedBox(height: 22),
            _menu(context, Icons.photo_library_outlined, 'UPLOAD FOTO', () => _pick(context)),
            const SizedBox(height: 12),
            _menu(context, Icons.camera_alt_outlined, 'AMBIL FOTO', () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const CameraScreen()));
            }),
            const SizedBox(height: 12),
            _menu(context, Icons.tune, 'TEMPLATE', () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const TemplateScreen()));
            }, outlined: true),
            const SizedBox(height: 12),
            _menu(context, Icons.photo_album_outlined, 'GALERI HASIL', () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const GalleryScreen()));
            }, outlined: true),
            const SizedBox(height: 22),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Template utama tersimpan di aplikasi. Pilih foto dari galeri atau ambil langsung dengan kamera. Tanggal, jam, dan lokasi akan diisi otomatis.',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _menu(BuildContext context, IconData icon, String text, VoidCallback onTap, {bool outlined = false}) {
    return SizedBox(
      height: 58,
      width: double.infinity,
      child: outlined
          ? OutlinedButton.icon(
              onPressed: onTap, icon: Icon(icon), label: Text(text),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppConstants.yamahaBlue,
                side: const BorderSide(color: AppConstants.yamahaBlue),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            )
          : FilledButton.icon(
              onPressed: onTap, icon: Icon(icon), label: Text(text),
              style: FilledButton.styleFrom(
                backgroundColor: AppConstants.yamahaBlue,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
    );
  }
}
