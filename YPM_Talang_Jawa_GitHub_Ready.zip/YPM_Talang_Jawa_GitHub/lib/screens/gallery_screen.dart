import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../services/gallery_service.dart';

class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});
  @override State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  List<File> _files = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final files = await GalleryService.listResults();
    if (mounted) setState(() => _files = files);
  }

  Future<void> _delete(File f) async {
    await f.delete();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Galeri Hasil')),
      body: _files.isEmpty
          ? const Center(child: Text('Belum ada hasil foto.'))
          : GridView.builder(
              padding: const EdgeInsets.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, crossAxisSpacing: 8, mainAxisSpacing: 8,
              ),
              itemCount: _files.length,
              itemBuilder: (_, i) {
                final f = _files[i];
                return Stack(
                  fit: StackFit.expand,
                  children: [
                    ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(f, fit: BoxFit.cover)),
                    Positioned(
                      right: 4, top: 4,
                      child: Row(children: [
                        CircleAvatar(
                          backgroundColor: Colors.black54,
                          child: IconButton(
                            icon: const Icon(Icons.share, color: Colors.white, size: 18),
                            onPressed: () => Share.shareXFiles([XFile(f.path)]),
                          ),
                        ),
                        const SizedBox(width: 4),
                        CircleAvatar(
                          backgroundColor: Colors.black54,
                          child: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.white, size: 18),
                            onPressed: () => _delete(f),
                          ),
                        ),
                      ]),
                    ),
                  ],
                );
              },
            ),
    );
  }
}
