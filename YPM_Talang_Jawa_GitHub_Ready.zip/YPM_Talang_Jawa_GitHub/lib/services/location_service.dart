import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';

class LocationService {
  static Future<String> getReadableLocation() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      return 'Lokasi tidak tersedia';
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      return 'Lokasi tidak diizinkan';
    }

    final position = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
    );

    try {
      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      if (placemarks.isEmpty) return 'Lokasi tidak diketahui';
      final p = placemarks.first;
      final parts = <String>[];
      for (final value in [p.name, p.subLocality, p.locality, p.subAdministrativeArea]) {
        if (value != null && value.trim().isNotEmpty && !parts.contains(value.trim())) {
          parts.add(value.trim());
        }
      }
      return parts.take(3).join(', ');
    } catch (_) {
      return 'Lokasi tidak diketahui';
    }
  }
}
