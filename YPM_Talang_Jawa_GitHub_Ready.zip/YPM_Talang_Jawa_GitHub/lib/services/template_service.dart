import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/template_model.dart';

class TemplateService {
  static const _key = 'ypm_template';

  static Future<TemplateModel> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return const TemplateModel();
    try {
      return TemplateModel.fromJson(jsonDecode(raw));
    } catch (_) {
      return const TemplateModel();
    }
  }

  static Future<void> save(TemplateModel model) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(model.toJson()));
  }
}
