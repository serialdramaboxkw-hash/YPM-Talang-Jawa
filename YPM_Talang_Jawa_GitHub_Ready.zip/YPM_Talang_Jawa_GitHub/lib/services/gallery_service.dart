import 'dart:io';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';

class GalleryService {
  static Future<Directory> appDirectory() async {
    return getApplicationDocumentsDirectory();
  }

  static Future<String> saveToAppGallery(File file) async {
    final dir = await appDirectory();
    final out = File('${dir.path}/${file.uri.pathSegments.last}');
    await file.copy(out.path);
    return out.path;
  }

  static Future<void> saveToDeviceGallery(File file) async {
    await Gal.putImage(file.path, album: 'YPM Talang Jawa');
  }
}
