import 'dart:io';
import 'package:flutter/material.dart';
import '../models/template_model.dart';
import '../utils/constants.dart';

class PhotoFrame extends StatelessWidget {
  final File? photo;
  final TemplateModel template;
  final String dateText;
  final String locationText;
  final bool showGuides;

  const PhotoFrame({
    super.key,
    required this.photo,
    required this.template,
    required this.dateText,
    required this.locationText,
    this.showGuides = false,
  });

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 0.75,
      child: LayoutBuilder(builder: (context, c) {
        final w = c.maxWidth, h = c.maxHeight;
        return Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(AppConstants.templateAsset, fit: BoxFit.cover),
            Positioned(
              left: w * template.photoLeft,
              top: h * template.photoTop,
              width: w * template.photoWidth,
              height: h * template.photoHeight,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: photo == null
                    ? Container(
                        color: Colors.white.withOpacity(.92),
                        alignment: Alignment.center,
                        child: const Text(
                          'FOTO MOTOR',
                          style: TextStyle(fontWeight: FontWeight.bold, color: AppConstants.yamahaBlue),
                        ),
                      )
                    : Image.file(photo!, fit: BoxFit.cover),
              ),
            ),
            Positioned(
              left: 0, right: 0, top: h * template.dateTop,
              child: Text(
                dateText,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14 * template.textScale,
                  fontWeight: FontWeight.w800,
                  color: AppConstants.yamahaDark,
                ),
              ),
            ),
            Positioned(
              left: 12, right: 12, top: h * template.locationTop,
              child: Text(
                locationText,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 13 * template.textScale,
                  fontWeight: FontWeight.w700,
                  color: AppConstants.yamahaDark,
                ),
              ),
            ),
            if (showGuides)
              Positioned(
                left: w * template.photoLeft,
                top: h * template.photoTop,
                width: w * template.photoWidth,
                height: h * template.photoHeight,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    border: Border.all(color: AppConstants.accentRed, width: 2),
                  ),
                ),
              ),
          ],
        );
      }),
    );
  }
}
