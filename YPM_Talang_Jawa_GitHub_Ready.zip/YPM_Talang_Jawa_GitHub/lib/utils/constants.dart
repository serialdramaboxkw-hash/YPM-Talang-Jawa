import 'package:flutter/material.dart';

class AppConstants {
  static const appName = 'YPM Talang Jawa';
  static const subtitle = 'Foto Serah Terima Motor';
  static const dealerAddress = 'Simpang Kepur';
  static const templateAsset = 'assets/serah_terima_template.png';

  static const yamahaBlue = Color(0xFF005BAC);
  static const yamahaDark = Color(0xFF003B73);
  static const accentRed = Color(0xFFE31B23);
  static const white = Colors.white;
}
