class TemplateModel {
  final double photoLeft;
  final double photoTop;
  final double photoWidth;
  final double photoHeight;
  final double dateTop;
  final double locationTop;
  final double textScale;

  const TemplateModel({
    this.photoLeft = 0.08,
    this.photoTop = 0.20,
    this.photoWidth = 0.84,
    this.photoHeight = 0.48,
    this.dateTop = 0.78,
    this.locationTop = 0.84,
    this.textScale = 1.0,
  });

  Map<String, dynamic> toJson() => {
    'photoLeft': photoLeft, 'photoTop': photoTop, 'photoWidth': photoWidth,
    'photoHeight': photoHeight, 'dateTop': dateTop,
    'locationTop': locationTop, 'textScale': textScale,
  };

  factory TemplateModel.fromJson(Map<String, dynamic> j) => TemplateModel(
    photoLeft: (j['photoLeft'] as num?)?.toDouble() ?? 0.08,
    photoTop: (j['photoTop'] as num?)?.toDouble() ?? 0.20,
    photoWidth: (j['photoWidth'] as num?)?.toDouble() ?? 0.84,
    photoHeight: (j['photoHeight'] as num?)?.toDouble() ?? 0.48,
    dateTop: (j['dateTop'] as num?)?.toDouble() ?? 0.78,
    locationTop: (j['locationTop'] as num?)?.toDouble() ?? 0.84,
    textScale: (j['textScale'] as num?)?.toDouble() ?? 1.0,
  );
}
