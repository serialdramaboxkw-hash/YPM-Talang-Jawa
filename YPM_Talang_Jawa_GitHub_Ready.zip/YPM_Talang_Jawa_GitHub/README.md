# YPM Talang Jawa

Aplikasi Android Flutter untuk membuat foto serah terima motor dengan template tetap YPM Talang Jawa.

## Fitur

- Template Yamaha-inspired tetap dan tersimpan di aplikasi.
- Upload foto dari galeri.
- Ambil foto dengan kamera.
- Crop/atur foto sebelum digunakan.
- Lokasi GPS dan nama lokasi yang mudah dibaca.
- Tanggal/waktu otomatis.
- Preview hasil.
- Export final menjadi PNG yang sudah menggabungkan template + foto + tanggal + lokasi.
- Simpan ke Galeri Android.
- Bagikan hasil.
- Pengaturan posisi/ukuran template tersimpan dengan SharedPreferences.
- Galeri hasil di dalam aplikasi.

## Build APK lewat GitHub

Lihat **README_GITHUB.md**. File `.github/workflows/build-apk.yml` akan membangun `app-release.apk` secara otomatis.

## Build lokal

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

APK berada di:

```text
build/app/outputs/flutter-apk/app-release.apk
```
