# YPM Talang Jawa — GitHub → APK Android

Project Flutter Android-only untuk membuat foto serah terima motor dengan template tetap YPM Talang Jawa.

## Cara paling mudah dari iPhone

1. Buat repository baru di GitHub, misalnya `ypm-talang-jawa`.
2. Upload **semua isi folder project ini** ke repository tersebut. Jangan upload file ZIP sebagai satu-satunya file.
3. Pastikan file berikut ada di repository:
   - `pubspec.yaml`
   - `lib/`
   - `android/`
   - `assets/serah_terima_template.png`
   - `.github/workflows/build-apk.yml`
4. Setelah upload, buka tab **Actions** di repository.
5. Workflow **Build APK Android** akan berjalan otomatis ketika branch `main` menerima perubahan.
6. Tunggu sampai status workflow menjadi hijau/`Success`.
7. Buka hasil workflow tersebut, cari bagian **Artifacts**, lalu download `ypm-talang-jawa-apk`.
8. Di dalam ZIP artifact ada `app-release.apk`.
9. Pindahkan APK ke HP Android lalu instal.

## Menjalankan build manual

Di GitHub buka:

**Actions → Build APK Android → Run workflow**

## File APK

Workflow menghasilkan:

`build/app/outputs/flutter-apk/app-release.apk`

GitHub Actions mengunggah file tersebut sebagai artifact bernama:

`ypm-talang-jawa-apk`

## Catatan

- APK ini adalah **release APK unsigned**. Cocok untuk instalasi pribadi/testing di HP Android.
- Untuk publikasi ke Google Play Store, sebaiknya tambahkan signing keystore dan konfigurasi Play App Signing.
- Aplikasi meminta akses kamera, lokasi, dan foto/media sesuai fungsi aplikasi.
- Template utama disimpan sebagai asset aplikasi sehingga tidak perlu upload template setiap kali membuat foto.
